import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
public class HelloForm extends HttpServlet {
public void doGet(HttpServletRequest req, HttpServletResponse res)
throws IOException, ServletException {
res.setContentType("text/html");
PrintWriter pw = res.getWriter();
pw.println("<link rel='stylesheet' type='text/css' href='css/main.css'>");
Connection con = null;
Statement stmt = null;
ResultSet rs = null;
pw.println("<style>");
pw.println("table {");
pw.println("font-family: arial, sans-serif; border: 1px solid black; width: 100%;}");
pw.println("td, th {");
pw.println("text-align: left; padding: 15px; font-size: 13px;}");
pw.println("th{background-color: #f2f2f2;}");
pw.println("</style>");
try {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con = DriverManager.getConnection("jdbc:odbc:myServlet");
stmt = con.createStatement();
pw.print("<br /><br /><h3> Student ID:");
pw.println(req.getParameter("stuid") + "&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp" +"Student Name:" + req.getParameter("stuname"));
pw.println("</h3></p><table>");
pw.println("<tr><td><h3>"+ req.getParameter("course")+"</h3></td></tr>");
for(int i = 1; i <= 4; i++){
pw.println("<tr><td><h2>Semester No: " + i+"</h2></td></tr>");
rs = stmt.executeQuery("SELECT* FROM courses where stud_prog='"+req.getParameter("course")+"' and semes='"+i+"'");
pw.println("<tr><th>Course Code</th><th>Title</th><th>Type</th><th>Pre Request</th><th>Credit Hours</th><th>Specialization</th></tr>");
while (rs.next()) {
pw.println("<tr><td>");
pw.println(rs.getString(2));
pw.println("</td><td>");
pw.println(rs.getString(3));
pw.println("</td><td>");
pw.println(rs.getString(4));
pw.println("</td><td>");
pw.println(rs.getString(5));
pw.println("</td><td>");
pw.println(rs.getString(6));
pw.println("</td><td>");
if(rs.getString(7)==null)
{
	pw.println("");
}
else{
pw.println(rs.getString(7));
}
pw.println("</td></tr>");

}




}




} catch (SQLException e) {
pw.println(e.getNextException());
} catch (ClassNotFoundException e) {
pw.println(e.getException());
} finally {
try {
if (rs != null) {
rs.close();
rs = null;
}
if (stmt != null) {
stmt.close();
stmt = null;
}
if (con != null) {
con.close();
con = null;
}
} catch (Exception e) {
pw.close();
}
}
}
}